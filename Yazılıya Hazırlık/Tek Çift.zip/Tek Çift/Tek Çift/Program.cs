﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tek_Çift
{
    class Program
    {
        static void Main(string[] args)
        {
            HESAPLA hesap = new HESAPLA();
            Console.Write("Sayı giriniz: ");
            int sayi = int.Parse(Console.ReadLine());
            if (sayi % 2 == 0)
            {
                hesap.ÇiftSayılar(sayi);
                Console.WriteLine("Sayınız Çifttir");
            }
            if (sayi % 2 != 0)
            {
                hesap.TekSayılar(sayi);
                Console.WriteLine("Sayınız Tektir");
            }
            Main(args);
        }
    }
}
