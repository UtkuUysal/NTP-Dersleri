﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tek_Çift
{
    class HESAPLA
    {
        public void ÇiftSayılar(int bitis)
        {
            for (int i = 0; i <= bitis; i += 2)
            {
                Console.WriteLine(i);
            }
        }
        public void TekSayılar(int bitis)
        {
            for (int i = 1; i <= bitis; i += 2)
            {
                Console.WriteLine(i);
            }
        }
    }
}
