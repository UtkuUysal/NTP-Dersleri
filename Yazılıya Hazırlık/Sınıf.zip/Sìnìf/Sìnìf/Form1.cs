﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sınıf
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        List<öğrenciler> ogrenciler = new List<öğrenciler>();
        private void button1_Click(object sender, EventArgs e)
        {
            string sınıf;
            sınıf = textBox1.Text;
            cmbSınıf.Items.Add(sınıf);
            comboBox2.Items.Add(sınıf);
            textBox1.Text = null;
        }
        öğrenciler ogr1 = new öğrenciler();
        private void button2_Click(object sender, EventArgs e)
        {
            ogr1.okulno = txtOkulNo.Text;
            ogr1.adı = txtAd.Text;
            ogr1.soyadı = txtSoyad.Text;
            ogr1.sınıfı = cmbSınıf.SelectedText;
            ogrenciler.Add(ogr1);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            {
                if (checkBox1.Checked == true)
                {
                    listBox1.Items.Add(ogr1.okulno);
                }
                if (checkBox2.Checked == true)
                {
                    listBox1.Items.Add(ogr1.adı);
                }
                if (checkBox3.Checked == true)
                {
                    listBox1.Items.Add(ogr1.adı);
                }
            }
        }
    }
}
