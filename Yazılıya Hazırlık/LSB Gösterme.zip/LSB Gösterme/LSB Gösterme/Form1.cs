﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LSB_Gösterme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        

        private void button2_Click(object sender, EventArgs e)
        {
            groupBox2.Enabled = true;
            groupBox1.Enabled =false;
            
        }
        List<int> sayilar = new List<int>();
        private void button1_Click(object sender, EventArgs e)
        {
            int sayi;
            sayi = int.Parse(txtEkleme.Text);
            sayilar.Add(sayi);
            txtEkleme.Text=null;
            

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {

                if (txtGösterme.Text=="")
            {
                for (int i = 0; i < sayilar.Count; i++)
                {
                    listBox1.Items.Add(sayilar[i]);
                }
            }
            else 
            {
                listBox1.Items.Clear();
                listBox1.Items.Add(sayilar[int.Parse(txtGösterme.Text)]);
            }
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Hata Message");
            }
          
        }
    }
}
